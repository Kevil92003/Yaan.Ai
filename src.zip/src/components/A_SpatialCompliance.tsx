import React, { useState, useEffect } from 'react';
import { PlotDimensions, ComplianceReport } from '../types';
import { calculateGDCR } from '../data';
import { Ruler, ShieldAlert, Navigation, Compass, LayoutGrid, Info, Eye } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  onReportChange: (report: ComplianceReport, plot: PlotDimensions) => void;
}

export default function A_SpatialCompliance({ onReportChange }: Props) {
  const [plot, setPlot] = useState<PlotDimensions>({
    width: 30,
    length: 40,
    cityZone: 'SURAT',
    roadFacing: 'NORTH',
    roadWidth: 18,
  });

  const [activeTab, setActiveTab] = useState<'parameters' | 'vastu'>('parameters');
  const [report, setReport] = useState<ComplianceReport>(calculateGDCR(plot));

  useEffect(() => {
    const newReport = calculateGDCR(plot);
    setReport(newReport);
    onReportChange(newReport, plot);
  }, [plot]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setPlot((prev) => ({
      ...prev,
      [name]: name === 'cityZone' || name === 'roadFacing' ? value : Number(value),
    }));
  };

  const area = plot.width * plot.length;

  // Compute responsive SVG container sizes (preserving ratio)
  const svgWidth = 400;
  const svgHeight = 400;
  const maxDim = Math.max(plot.width, plot.length);
  const scale = 300 / maxDim; // scale factor to fit within 300px with margins

  const plotSvgW = plot.width * scale;
  const plotSvgH = plot.length * scale;
  const offsetX = (svgWidth - plotSvgW) / 2;
  const offsetY = (svgHeight - plotSvgH) / 2;

  // Setbacks in local coordinates
  const { front, rear, sideLeft, sideRight } = report.setbacks;
  const frontPX = front * scale;
  const rearPX = rear * scale;
  const leftPX = sideLeft * scale;
  const rightPX = sideRight * scale;

  // Calculate inner buildable coordinate bounds
  const innerX = offsetX + leftPX;
  const innerY = offsetY + (plot.roadFacing === 'NORTH' ? frontPX : (plot.roadFacing === 'SOUTH' ? rearPX : leftPX)); // simplified for display
  const innerW = Math.max(0, plotSvgW - leftPX - rightPX);
  const innerH = Math.max(0, plotSvgH - (plot.roadFacing === 'NORTH' || plot.roadFacing === 'SOUTH' ? frontPX + rearPX : leftPX + rightPX));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-white relative z-10" id="compliance-workspace">
      {/* Parameters Panel */}
      <div className="lg:col-span-5 bg-black/40 backdrop-blur-md tech-border p-6 flex flex-col justify-between" id="parameters-panel">
        <div>
          <div className="flex items-center space-x-3 border-b border-white/10 pb-4 mb-6">
            <LayoutGrid className="w-4 h-4 text-white" />
            <span className="text-xs font-bold tracking-[0.2em] font-mono text-white uppercase">SYS_ENGINE_A: PARAMETERS</span>
          </div>

          <div className="space-y-4">
            <div>
              <span className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-2">Jurisdiction Region</span>
              <select
                id="cityZone"
                name="cityZone"
                value={plot.cityZone}
                onChange={handleInputChange}
                className="w-full bg-black/60 tech-border p-2.5 text-xs font-mono uppercase tracking-wider text-white outline-none focus:border-white transition-all rounded-none"
              >
                <option value="SURAT">SMC — Surat Unified Grid</option>
                <option value="AHMEDABAD">AUDA — Ahmedabad Macro Zone</option>
                <option value="GIFT_CITY">GIFT CITY — Special High-Density Node</option>
                <option value="RAJKOT">RMC — Rajkot Structural Codes</option>
                <option value="VADODARA">VUDA — Vadodara Regional Matrix</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-2">Plot Width (M)</span>
                <input
                  id="plot-width-input"
                  name="width"
                  type="number"
                  min="5"
                  max="500"
                  value={plot.width}
                  onChange={handleInputChange}
                  className="w-full bg-black/60 tech-border p-2 text-xs font-mono text-white outline-none focus:border-white transition-all rounded-none animate-none"
                />
              </div>
              <div>
                <span className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-2">Plot Length (M)</span>
                <input
                  id="plot-length-input"
                  name="length"
                  type="number"
                  min="5"
                  max="500"
                  value={plot.length}
                  onChange={handleInputChange}
                  className="w-full bg-black/60 tech-border p-2 text-xs font-mono text-white outline-none focus:border-white transition-all rounded-none animate-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-2">Road Orientation</span>
                <select
                  id="roadFacing"
                  name="roadFacing"
                  value={plot.roadFacing}
                  onChange={handleInputChange}
                  className="w-full bg-black/60 tech-border p-2 text-xs font-mono uppercase text-white outline-none focus:border-white transition-all rounded-none"
                >
                  <option value="NORTH">NORTH</option>
                  <option value="SOUTH">SOUTH</option>
                  <option value="EAST">EAST</option>
                  <option value="WEST">WEST</option>
                </select>
              </div>
              <div>
                <span className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-2">Road Width (M)</span>
                <input
                  id="road-width-input"
                  name="roadWidth"
                  type="number"
                  min="3"
                  max="120"
                  value={plot.roadWidth}
                  onChange={handleInputChange}
                  className="w-full bg-black/60 tech-border p-2 text-xs font-mono text-white outline-none focus:border-white transition-all rounded-none animate-none"
                />
              </div>
            </div>
          </div>

          <div className="mt-8 bg-black/60 p-4 tech-border font-mono text-xs text-white/60 space-y-2">
            <div className="flex justify-between border-b border-white/10 pb-1.5">
              <span>PLOT AREA:</span>
              <span className="text-white font-medium">{area.toFixed(1)} m²</span>
            </div>
            <div className="flex justify-between border-b border-white/10 pb-1.5">
              <span>MUNICIPAL_CODE:</span>
              <span className="text-white font-bold tracking-tight break-all text-right max-w-[200px]">{report.applicableCode}</span>
            </div>
            <div className="flex justify-between">
              <span>FSI LIMIT:</span>
              <span className="text-white font-bold">MAX {report.setbacks.maxFSI.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="mt-6 border-t border-white/10 pt-6">
          <div className="flex space-x-2">
            <button
              id="setbacks-tab-btn"
              onClick={() => setActiveTab('parameters')}
              className={`flex-1 py-2 font-mono text-xs uppercase tracking-wider rounded-none tech-border transition-all cursor-pointer ${
                activeTab === 'parameters'
                  ? 'bg-white text-black font-bold border-white'
                  : 'bg-white/5 border-white/5 text-white/50 hover:bg-white/10 hover:text-white'
              }`}
            >
              Setback Summary
            </button>
            <button
              id="vastu-tab-btn"
              onClick={() => setActiveTab('vastu')}
              className={`flex-1 py-2 font-mono text-xs uppercase tracking-wider rounded-none tech-border transition-all cursor-pointer ${
                activeTab === 'vastu'
                  ? 'bg-white text-black font-bold border-white'
                  : 'bg-white/5 border-white/5 text-white/50 hover:bg-white/10 hover:text-white'
              }`}
            >
              Vastu Vectors
            </button>
          </div>

          <div className="mt-4 min-h-[140px] bg-black/60 p-4 tech-border text-xs">
            {activeTab === 'parameters' ? (
              <div className="space-y-4 font-mono">
                <div className="grid grid-cols-2 gap-2 text-white/60">
                  <div className="tech-border p-2 bg-white/5">
                    <span className="text-white/40 block text-[9px] tracking-wider uppercase">FRONT SETBACK</span>
                    <span className="text-white text-sm font-bold">{front}m</span>
                  </div>
                  <div className="tech-border p-2 bg-white/5">
                    <span className="text-white/40 block text-[9px] tracking-wider uppercase">REAR SETBACK</span>
                    <span className="text-white text-sm font-bold">{rear}m</span>
                  </div>
                  <div className="tech-border p-2 bg-white/5">
                    <span className="text-white/40 block text-[9px] tracking-wider uppercase">LEFT SETBACK</span>
                    <span className="text-white text-sm font-bold">{sideLeft}m</span>
                  </div>
                  <div className="tech-border p-2 bg-white/5">
                    <span className="text-white/40 block text-[9px] tracking-wider uppercase">RIGHT SETBACK</span>
                    <span className="text-white text-sm font-bold">{sideRight}m</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-3 font-mono">
                <div className="flex items-center justify-between text-[11px] border-b border-neutral-900 pb-1">
                  <span className="text-amber-400 font-semibold uppercase tracking-widest flex items-center">
                    <Compass className="w-3.5 h-3.5 mr-1.5" /> Auspicious Alignment
                  </span>
                  <span className="text-emerald-500 text-[10px] uppercase font-bold tracking-wider">● Optimized</span>
                </div>
                <div className="grid grid-cols-2 gap-2.5 text-[10px] text-neutral-400">
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                    <span>Agni (SE): Fire</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></span>
                    <span>Ishanya (NE): Water</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
                    <span>Nairutya (SW): Earth</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-violet-500 animate-pulse"></span>
                    <span>Vayu (NW): Air</span>
                  </div>
                </div>
                <p className="text-[11px] text-neutral-500 leading-relaxed border-t border-neutral-900 pt-2 font-sans italic">
                  {report.vastuAssessment.suggestions[0]}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Interactive Architectural CAD Visualizer */}
      <div className="lg:col-span-7 bg-black/40 backdrop-blur-md tech-border flex flex-col justify-between align-middle" id="visualizer-container">
        <div className="border-b border-white/10 p-4 flex justify-between items-center bg-black/80 font-mono">
          <div className="flex items-center space-x-2">
            <Ruler className="text-white w-4 h-4" />
            <span className="text-xs uppercase tracking-widest text-white font-bold">CAD_VECTOR: SCHEMATIC MATRIX ({plot.width}m x {plot.length}m)</span>
          </div>
          <span className="text-[9px] opacity-40 uppercase tracking-widest">LAYER_SCALE_CALIBRATED</span>
        </div>

        {/* CAD Schematic Canvas Area */}
        <div className="relative flex-1 min-h-[380px] flex items-center justify-center p-6 arch-grid overflow-hidden">
          {/* Compass Rose */}
          <div className="absolute right-4 top-4 tech-border p-2.5 bg-black/85 backdrop-blur-sm rounded-none flex flex-col items-center">
            <Navigation className={`w-5 h-5 text-white/50 transition-all duration-500`} style={{ transform: `rotate(${plot.roadFacing === 'NORTH' ? 0 : plot.roadFacing === 'EAST' ? 90 : plot.roadFacing === 'SOUTH' ? 180 : 270}deg)` }} />
            <span className="text-[9px] font-mono mt-1 text-white/60 font-semibold tracking-wider">{plot.roadFacing}</span>
          </div>

          <svg width={svgWidth} height={svgHeight} className="overflow-visible select-none drop-shadow-2xl">
            {/* Draw plot grid helpers */}
            <g className="opacity-15 font-mono text-[9px] text-neutral-750">
              <line x1={0} y1={offsetY} x2={svgWidth} y2={offsetY} stroke="#333" strokeDasharray="2" />
              <line x1={offsetX} y1={0} x2={offsetX} y2={svgHeight} stroke="#333" strokeDasharray="2" />
              <line x1={offsetX + plotSvgW} y1={0} x2={offsetX + plotSvgW} y2={svgHeight} stroke="#333" strokeDasharray="2" />
              <line x1={0} y1={offsetY + plotSvgH} x2={svgWidth} y2={offsetY + plotSvgH} stroke="#333" strokeDasharray="2" />
            </g>

            {/* Plot outer boundary */}
            <rect
              x={offsetX}
              y={offsetY}
              width={plotSvgW}
              height={plotSvgH}
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="1.5"
              id="outer-plot-rect"
            />

            {/* Setback buffer shade pattern */}
            <rect
              x={offsetX}
              y={offsetY}
              width={plotSvgW}
              height={plotSvgH}
              fill="rgba(255, 255, 255, 0.03)"
              pointerEvents="none"
            />

            {/* Inner buildable pocket core definition */}
            {innerW > 0 && innerH > 0 && (
              <>
                <rect
                  x={innerX}
                  y={innerY}
                  width={innerW}
                  height={innerH}
                  fill="none"
                  stroke="#FFFFFF"
                  strokeWidth="1.2"
                  strokeDasharray="4 2"
                  id="buildable-envelope"
                />
                
                {/* Visual Label inside envelope */}
                <text
                  x={innerX + innerW / 2}
                  y={innerY + innerH / 2}
                  textAnchor="middle"
                  fill="#FFFFFF"
                  fontFamily="JetBrains Mono"
                  fontSize="9px"
                  fontStyle="italic"
                  className="opacity-75 tracking-wider select-none font-bold"
                >
                  BUILDABLE ENVELOPE
                </text>
              </>
            )}

            {/* Vastu coordinate anchors overlay */}
            <g id="vastu-anchors">
              {/* North-East (Ishanya) dot */}
              <circle cx={offsetX + plotSvgW} cy={offsetY} r="4" fill="#FFFFFF" className="animate-pulse" />
              <text x={offsetX + plotSvgW + 8} y={offsetY - 2} fill="#FFFFFF" fontFamily="JetBrains Mono" fontSize="8px" className="opacity-80">NE (ISHANYA)</text>

              {/* South-East (Agni) dot */}
              <circle cx={offsetX + plotSvgW} cy={offsetY + plotSvgH} r="4" fill="#FFFFFF" className="animate-pulse" />
              <text x={offsetX + plotSvgW + 8} y={offsetY + plotSvgH + 8} fill="#FFFFFF" fontFamily="JetBrains Mono" fontSize="8px" className="opacity-80">SE (AGNI)</text>

              {/* South-West (Nairutya) dot */}
              <circle cx={offsetX} cy={offsetY + plotSvgH} r="4" fill="#FFFFFF" className="animate-pulse" />
              <text x={offsetX - 70} y={offsetY + plotSvgH + 8} fill="#FFFFFF" fontFamily="JetBrains Mono" fontSize="8px" className="opacity-80">SW (NAIRUTYA)</text>

              {/* North-West (Vayu) dot */}
              <circle cx={offsetX} cy={offsetY} r="4" fill="#FFFFFF" className="animate-pulse" />
              <text x={offsetX - 55} y={offsetY - 2} fill="#FFFFFF" fontFamily="JetBrains Mono" fontSize="8px" className="opacity-80">NW (VAYU)</text>
            </g>

            {/* Visual dimension guidelines */}
            <g className="font-mono text-[9px]" fill="#888">
              {/* Width dim line */}
              <line x1={offsetX} y1={offsetY - 15} x2={offsetX + plotSvgW} y2={offsetY - 15} stroke="#555" strokeWidth="1" />
              <path d={`M ${offsetX} ${offsetY - 18} L ${offsetX} ${offsetY - 12} M ${offsetX + plotSvgW} ${offsetY - 18} L ${offsetX + plotSvgW} ${offsetY - 12}`} stroke="#555" strokeWidth="1" />
              <text x={offsetX + plotSvgW / 2} y={offsetY - 20} textAnchor="middle" fill="#FFF" className="opacity-80">{plot.width}m (X-PLANE)</text>

              {/* Length dim line */}
              <line x1={offsetX - 15} y1={offsetY} x2={offsetX - 15} y2={offsetY + plotSvgH} stroke="#555" strokeWidth="1" />
              <path d={`M ${offsetX - 18} ${offsetY} L ${offsetX - 12} ${offsetY} M ${offsetX - 18} ${offsetY + plotSvgH} L ${offsetX - 12} ${offsetY + plotSvgH}`} stroke="#555" strokeWidth="1" />
              <text x={offsetX - 22} y={offsetY + plotSvgH / 2} textAnchor="middle" transform={`rotate(-90, ${offsetX - 22}, ${offsetY + plotSvgH / 2})`} fill="#FFF" className="opacity-80">{plot.length}m (Y-PLANE)</text>
            </g>

            {/* Thick Main Road line marker */}
            <g id="road-marker" className="opacity-90">
              {plot.roadFacing === 'NORTH' && (
                <rect x={offsetX - 20} y={offsetY - 12} width={plotSvgW + 40} height="5" fill="#FFF" opacity="0.3" />
              )}
              {plot.roadFacing === 'SOUTH' && (
                <rect x={offsetX - 20} y={offsetY + plotSvgH + 7} width={plotSvgW + 40} height="5" fill="#FFF" opacity="0.3" />
              )}
              {plot.roadFacing === 'EAST' && (
                <rect x={offsetX + plotSvgW + 7} y={offsetY - 20} width="5" height={plotSvgH + 40} fill="#FFF" opacity="0.3" />
              )}
              {plot.roadFacing === 'WEST' && (
                <rect x={offsetX - 12} y={offsetY - 20} width="5" height={plotSvgH + 40} fill="#FFF" opacity="0.3" />
              )}
            </g>
          </svg>

          {/* HUD Overlay Details */}
          <div className="absolute left-4 bottom-4 p-3 bg-black/85 backdrop-blur-sm tech-border font-mono text-[9px] text-white/50 space-y-1">
            <div className="flex items-center space-x-1.5">
              <span className="w-1.5 h-1.5 bg-white inline-block border border-white/50"></span>
              <span>INNER_BOUNDS: ENVELOPE_CORE</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-1.5 h-1.5 bg-white inline-block"></span>
              <span>OUTER_BOUNDS: PLOT_PERIMETER</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-1.5 h-1.5 bg-white/20 inline-block"></span>
              <span>SETBACKS: STRICT_BUFFER_UNUSABLE</span>
            </div>
          </div>
        </div>

        {/* Municipal Validation Footer summary */}
        <div className="bg-black/90 border-t border-white/10 p-4 font-mono text-xs flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <span className="text-[10px] opacity-40 uppercase">SYS_GRID_CODE:</span>
            <span className="text-white font-semibold">{report.applicableCode}</span>
          </div>
          <div>
            <span className="text-[10px] opacity-40 uppercase mr-2">VERIFICATION:</span>
            <span className={`px-2 py-0.5 text-[9px] font-bold tracking-widest uppercase tech-border ${
              report.boundsCompliant 
                ? 'bg-white text-black font-semibold' 
                : 'bg-red-950/20 text-red-400 border-red-500/50'
            }`}>
              {report.boundsCompliant ? 'PASS_COMPLIANT' : 'FAIL_CORES_EXCEEDED'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
