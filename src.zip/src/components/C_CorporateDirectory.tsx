import React, { useState } from 'react';
import { PlotDimensions, ComplianceReport, RealEstateEnterprise } from '../types';
import { REAL_ESTATE_DIRECTORY } from '../data';
import { Building2, User2, Binary, Cpu, TrendingUp, Info } from 'lucide-react';

interface Props {
  activePlot: PlotDimensions;
  activeReport: ComplianceReport;
}

export default function C_CorporateDirectory({ activePlot, activeReport }: Props) {
  const [selectedEntId, setSelectedEntId] = useState<string>('adani');

  const activeEnterprise = REAL_ESTATE_DIRECTORY.find(e => e.id === selectedEntId) || REAL_ESTATE_DIRECTORY[0];

  // Compute a dynamic "Corporate Compatibility Index" based on Plot specs
  const getCompatibilityScore = (ent: RealEstateEnterprise): number => {
    let score = 75; // base score

    if (activePlot.cityZone === 'GIFT_CITY') {
      if (ent.id === 'adani' || ent.id === 'shivalik') score += 20; // skyscraper ready
      if (ent.id === 'bakeri') score -= 15; // horizontal developer less fitting for GIFT city towers
    } else if (activePlot.cityZone === 'SURAT') {
      if (ent.id === 'avadh') score += 18; // Avadh operates premium luxury in Surat
      if (ent.id === 'shivalik') score += 10;
    } else if (activePlot.cityZone === 'AHMEDABAD') {
      if (ent.id === 'shivalik' || ent.id === 'bakeri') score += 15;
    } else if (activePlot.cityZone === 'VADODARA') {
      if (ent.id === 'sangath') score += 15; // Green compliance models
    }

    // FSI adjustments
    if (activeReport.setbacks.maxFSI >= 3.0) {
      if (ent.id === 'adani' || ent.id === 'shivalik') score += 8;
    } else {
      if (ent.id === 'bakeri' || ent.id === 'sangath') score += 10;
    }

    return Math.min(100, Math.max(40, score));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-white text-xs max-w-7xl mx-auto relative z-10" id="corporate-directory-workspace">
      {/* Enterprise Directory List Panel */}
      <div className="lg:col-span-4 bg-black/40 backdrop-blur-md tech-border p-5 flex flex-col justify-between" id="corporate-list-panel">
        <div>
          <div className="flex items-center space-x-2.5 border-b border-white/10 pb-4 mb-4">
            <Building2 className="w-4 h-4 text-white" />
            <span className="text-xs font-bold tracking-[0.2em] font-mono text-white uppercase">SYS_ENGINE_C: ENTERPRISES</span>
          </div>

          <div className="space-y-2">
            {REAL_ESTATE_DIRECTORY.map((ent) => {
              const compScore = getCompatibilityScore(ent);
              const isActive = selectedEntId === ent.id;
              return (
                <button
                  key={ent.id}
                  id={`ent-selector-${ent.id}`}
                  onClick={() => setSelectedEntId(ent.id)}
                  className={`w-full text-left p-4 font-mono transition-all border rounded-none flex items-center justify-between cursor-pointer ${
                    isActive
                      ? 'border-white bg-white text-black font-bold'
                      : 'border-white/5 bg-transparent text-white/50 hover:border-white/20 hover:text-white'
                  }`}
                >
                  <div className="space-y-1">
                    <span className={`font-bold text-xs block ${isActive ? 'text-black' : 'text-white'}`}>{ent.name}</span>
                    <span className={`text-[9px] font-sans tracking-wide block truncate max-w-[190px] ${isActive ? 'text-black/70' : 'text-white/40'}`}>
                      Founder: {ent.founder}
                    </span>
                  </div>

                  <div className="text-right flex flex-col items-end">
                    <span className="text-[10px] font-bold">{compScore}%</span>
                    <span className={`text-[8px] block uppercase font-mono tracking-tight ${isActive ? 'text-black/50' : 'text-white/30'}`}>ALIGNMENT</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-white/10 font-mono text-[9px] text-white/40 flex items-center space-x-1.5 leading-relaxed">
          <Info className="w-3.5 h-3.5 text-white/30 flex-shrink-0" />
          <span className="uppercase tracking-wider">Dynamic compatibility calculated from plot coordinates & jurisdiction zones.</span>
        </div>
      </div>

      {/* Enterprise High-Fidelity Specs Profile View */}
      <div className="lg:col-span-8 bg-black/40 backdrop-blur-md tech-border p-6 flex flex-col justify-between" id="corporate-profile-view">
        <div>
          {/* Header */}
          <div className="flex flex-col md:flex-row md:justify-between md:items-start border-b border-white/10 pb-4 mb-6">
            <div>
              <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">ENTERPRISE_PROFILE_SEC:</span>
              <h2 className="text-sm font-bold uppercase font-mono tracking-[0.1em] text-white mt-1">{activeEnterprise.name}</h2>
              <div className="flex items-center space-x-2 mt-1.5 text-white/60 font-mono text-[10px]">
                <User2 className="w-3.5 h-3.5 text-white/40" />
                <span>FOUNDER: <b className="text-white font-semibold font-sans">{activeEnterprise.founder}</b></span>
              </div>
            </div>
            
            <div className="mt-4 md:mt-0 bg-white/5 tech-border p-2.5 text-right font-mono rounded-none">
              <span className="text-[9px] text-white/45 uppercase tracking-wider block">COMPATIBILITY ALIGNMENT</span>
              <span className="text-sm font-bold text-white">{getCompatibilityScore(activeEnterprise)}%</span>
            </div>
          </div>

          {/* Specialty Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5" id="corporate-spec-bento">
            {/* Signature Specialty Card */}
            <div className="tech-border bg-white/5 p-4 space-y-2">
              <span className="text-[10px] font-semibold text-white/80 tracking-wider font-mono flex items-center uppercase">
                <Cpu className="w-3.5 h-3.5 text-white mr-2" /> Corporate Specialization
              </span>
              <p className="text-white/60 leading-normal text-xs">{activeEnterprise.specialty}</p>
            </div>

            {/* Signature Style Card */}
            <div className="tech-border bg-white/5 p-4 space-y-2">
              <span className="text-[10px] font-semibold text-white/80 tracking-wider font-mono flex items-center uppercase">
                <Binary className="w-3.5 h-3.5 text-white mr-2" /> Signature Design Style
              </span>
              <p className="text-white/60 leading-normal text-xs">{activeEnterprise.signatureStyle}</p>
            </div>

            {/* BIM Specification */}
            <div className="tech-border bg-white/5 p-4 space-y-2">
              <span className="text-[10px] font-semibold text-white/80 tracking-wider font-mono flex items-center uppercase">
                <Binary className="w-3.5 h-3.5 text-white/40 mr-2" /> BIM Level & Design Coordinates
              </span>
              <p className="text-white/50 font-mono text-[11px] leading-relaxed">{activeEnterprise.bimDetail}</p>
            </div>

            {/* Load / Thermal Specifications */}
            <div className="tech-border bg-white/5 p-4 space-y-2">
              <span className="text-[10px] font-semibold text-white/80 tracking-wider font-mono flex items-center uppercase">
                <Cpu className="w-3.5 h-3.5 text-white/40 mr-2" /> Core Load & Thermal Metrics
              </span>
              <p className="text-white/50 font-mono text-[11px] leading-relaxed">{activeEnterprise.loadThermalParams}</p>
            </div>
          </div>
        </div>

        {/* Strategic Market Alignment Advice */}
        <div className="border-t border-white/10 pt-6 mt-8 space-y-3" id="corporate-market-align">
          <div className="flex items-center space-x-2 text-[10px] font-mono text-white/80 uppercase tracking-widest">
            <TrendingUp className="w-4 h-4 text-white" />
            <span>STUDIO ALIGNMENT & CRITICAL ADVICE</span>
          </div>
          <div className="bg-white/5 tech-border p-4 font-mono text-[11px] text-white/60 leading-relaxed rounded-none">
            <span className="text-[10px] text-white uppercase block mb-1 font-bold tracking-wider">CRITICAL COMPLIANCE RECOMMENDATION:</span>
            To align perfectly with {activeEnterprise.name}&apos;s construction styles, configure your active layout to adhere strictly to:{' '}
            <span className="text-white italic font-mono font-medium">{activeEnterprise.marketAlignment}</span>. Set target FSI to match{' '}
            <span className="text-white font-bold underline">{activeReport.setbacks.maxFSI.toFixed(2)}</span> under{' '}
            <span className="text-white font-medium">{activePlot.cityZone}</span> jurisdiction boundaries.
          </div>
        </div>
      </div>
    </div>
  );
}
