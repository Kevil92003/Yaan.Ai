import React, { useState } from 'react';
import { PlotDimensions, ComplianceReport, UniversityNode } from '../types';
import { UNIVERSITIES } from '../data';
import { GraduationCap, Award, CheckSquare, MessageSquareCode, Send, HelpCircle, Loader2 } from 'lucide-react';

interface Props {
  activePlot: PlotDimensions;
  activeReport: ComplianceReport;
}

export default function B_AcademicKnowledge({ activePlot, activeReport }: Props) {
  const [selectedUniId, setSelectedUniId] = useState<string>('cept');
  const [juryQuestion, setJuryQuestion] = useState<string>('');
  const [juryFocus, setJuryFocus] = useState<string>('');
  const [userDefense, setUserDefense] = useState<string>('');
  const [juryFeedback, setJuryFeedback] = useState<string>('');
  const [isLoadingQuestion, setIsLoadingQuestion] = useState<boolean>(false);
  const [isLoadingFeedback, setIsLoadingFeedback] = useState<boolean>(false);
  
  const university = UNIVERSITIES.find(u => u.id === selectedUniId) || UNIVERSITIES[0];

  const handleUniSelect = (id: string) => {
    setSelectedUniId(id);
    setJuryQuestion('');
    setJuryFocus('');
    setUserDefense('');
    setJuryFeedback('');
  };

  const handleGenerateQuestion = async () => {
    setIsLoadingQuestion(true);
    setJuryQuestion('');
    setJuryFeedback('');
    setUserDefense('');
    
    try {
      const response = await fetch('/api/gemini/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Act as a senior, strict, and highly distinguished architectural jury professor at ${university.name}.
We are conducting a live thesis defense for a project with the following dimensions:
- Plot Parameters: ${activePlot.width}m width x ${activePlot.length}m length in ${activePlot.cityZone} jurisdiction zone.
- Front Setback: ${activeReport.setbacks.front}m, Rear Setback: ${activeReport.setbacks.rear}m.
- Proposed FSI: ${activeReport.setbacks.maxFSI.toFixed(2)}.

Present a highly specific, challenging, and mathematically rigorous question testing the student's mastery of ${university.focus} and how they resolved structural load distributions, lateral shear, or Vastu compliance on this specific footprint. 
Do not greet or write fluffy introductions. Ask the question directly with professional architectural vocabulary. Keep it under 100 words.`,
          contextSystem: `You represent the elite academic jury panel of ${university.name}. Your tone is demanding, severe, and purely architectural.`
        })
      });
      
      const data = await response.json();
      if (data.text) {
        setJuryQuestion(data.text);
        setJuryFocus(university.focus);
      } else {
        setJuryQuestion('Jury simulation unavailable. Standard question: Elaborate on how your core structural configuration manages vertical load balance on this layout.');
      }
    } catch (err) {
      console.error(err);
      setJuryQuestion('Jury critical link offline. Standard check: How does this layout address environmental wind velocity gradients?');
    } finally {
      setIsLoadingQuestion(false);
    }
  };

  const handleSubmitDefense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userDefense.trim()) return;

    setIsLoadingFeedback(true);
    setJuryFeedback('');

    try {
      const response = await fetch('/api/gemini/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `You are the Thesis Review Panel of ${university.name} chaired by Mr. Kevil Solanki's intelligence module.
Review the following thesis defense response from an architecture student.
JURY CRITICAL INQUIRY:
"${juryQuestion}"

STUDENT DEFENSE COMPOSITION:
"${userDefense}"

PROJECT CONTEXT:
- Layout: ${activePlot.width}m width x ${activePlot.length}m length in ${activePlot.cityZone}
- Structural Focus: ${university.focus}

Evaluate the student's defense. Provide:
1. FORMAL GRADE (Choose strictly from: APPROVED (A+), COMPLIANT (B), CONDITIONAL MINIMUM (C), REJECTED VECTORS (F))
2. CRITICAL AUDIT: 2-3 bullet points analyzing their structural arguments, math validity, and local jurisdictional code adherence.
3. ADAPTIVE REMEDIATION: One geometric guideline to correct their structural flaws.
Maintain a strict, clean, professional, and architectural tone. No emojis or marketing hype.`,
          contextSystem: `Review panel at ${university.name}. Tone is strict, critical, computational, and highly technical.`
        })
      });

      const data = await response.json();
      setJuryFeedback(data.text || 'Audit feedback system offline.');
    } catch (err) {
      console.error(err);
      setJuryFeedback('Audit connection failure. Standard feedback: Structure displays high eccentricity. Remediate lateral column distribution.');
    } finally {
      setIsLoadingFeedback(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-white text-xs max-w-7xl mx-auto relative z-10" id="academic-panel-container">
      {/* Target Institutional Repositories list */}
      <div className="lg:col-span-4 bg-black/40 backdrop-blur-md tech-border p-5 flex flex-col justify-between" id="institution-selectors">
        <div>
          <div className="flex items-center space-x-2.5 border-b border-white/10 pb-4 mb-4">
            <GraduationCap className="w-4 h-4 text-white" />
            <span className="text-xs font-bold tracking-[0.2em] font-mono text-white uppercase">SYS_ENGINE_B: INSTITUTES</span>
          </div>

          <div className="space-y-2">
            {UNIVERSITIES.map((uni) => (
              <button
                key={uni.id}
                id={`uni-selector-${uni.id}`}
                onClick={() => handleUniSelect(uni.id)}
                className={`w-full text-left p-3.5 font-mono transition-all border rounded-none flex flex-col justify-between cursor-pointer ${
                  selectedUniId === uni.id
                    ? 'border-white bg-white text-black font-bold'
                    : 'border-white/5 bg-transparent text-white/50 hover:border-white/20 hover:text-white'
                }`}
              >
                <div className="flex justify-between items-start">
                  <span className={`font-semibold text-xs ${selectedUniId === uni.id ? 'text-black' : 'text-white/80'}`}>{uni.name}</span>
                  <Award className={`w-3.5 h-3.5 ${selectedUniId === uni.id ? 'text-black font-bold' : 'text-white/20'}`} />
                </div>
                <span className={`text-[10px] mt-1 font-sans tracking-tight leading-sm truncate max-w-[240px] ${selectedUniId === uni.id ? 'text-black/70' : 'text-white/40'}`}>
                  {uni.focus}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-white/10 font-mono text-[9px] text-white/40 leading-relaxed uppercase tracking-wider">
          <span>SELECT REPOSITORY TO EXTRACT SYLLABI & TRIAL JURY PARAMETERS</span>
        </div>
      </div>

      {/* University syllabus detail AND Jury Simulator */}
      <div className="lg:col-span-8 space-y-6" id="university-content-view">
        {/* Course details */}
        <div className="bg-black/40 backdrop-blur-md tech-border p-6" id="syllabi-display-card">
          <div className="flex justify-between items-start border-b border-white/10 pb-3 mb-4">
            <div>
              <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">ACTIVE_NODE_REP:</span>
              <h2 className="text-sm font-bold uppercase font-mono tracking-wider text-white mt-1">{university.name}</h2>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-white/40 font-mono tracking-wider">DELIVERABLE:</span>
              <span className="block text-[11px] font-sans font-medium text-white/90">{university.keyDeliverable}</span>
            </div>
          </div>

          <div className="space-y-6">
            {university.syllabi.map((syllabus, index) => (
              <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4 border-b border-white/10 pb-4 last:border-b-0 last:pb-0">
                <div className="space-y-2">
                  <span className="text-[9px] bg-white text-black font-bold px-2 py-0.5 tracking-wider font-mono block w-fit">
                    {syllabus.semester}
                  </span>
                  <h3 className="text-xs font-semibold text-white uppercase">{syllabus.courseName}</h3>
                  <div className="pt-2">
                    <span className="text-[9px] font-mono text-white/40 uppercase tracking-wider block mb-1">Grading Metric Weight:</span>
                    <ul className="space-y-1 font-mono text-[10px] text-white/60">
                      {syllabus.gradingFocus.map((focus, i) => (
                        <li key={i} className="flex items-center space-x-1">
                          <span className="text-white mr-1">▫</span>
                          <span>{focus}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="bg-white/5 tech-border p-3.5 space-y-1.5 animate-none">
                  <span className="text-[10px] font-semibold tracking-wider font-mono text-white/70 flex items-center">
                    <CheckSquare className="w-3 h-3 text-white/55 mr-1.5" /> SUBMISSION CHECKLIST
                  </span>
                  <ul className="space-y-1.5 font-sans text-xs text-white/60">
                    {syllabus.submissionCriteria.map((criteria, i) => (
                      <li key={i} className="flex items-start">
                        <span className="text-white/60 mr-2 font-mono text-[10px] mt-0.5">▪</span>
                        <span>{criteria}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Jury Defense Simulator */}
        <div className="bg-black/40 backdrop-blur-md tech-border p-6 space-y-4 animate-none" id="jury-defense-simulator">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center space-x-2">
              <MessageSquareCode className="w-4 h-4 text-white" />
              <span className="text-xs font-bold uppercase tracking-[0.15em] font-mono text-white/95">JURY_DEFENSE: LIVE SIMULATOR</span>
            </div>
            <button
              id="generate-jury-btn"
              onClick={handleGenerateQuestion}
              disabled={isLoadingQuestion}
              className="px-3.5 py-1.5 bg-white border border-white text-black font-mono font-bold text-[10px] uppercase rounded-none transition-all flex items-center cursor-pointer hover:bg-white/80"
            >
              {isLoadingQuestion ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> SYNTHESIZING SURVEY
                </>
              ) : (
                <>
                  <HelpCircle className="w-3.5 h-3.5 mr-1.5" /> INIT_defense_QUESTION
                </>
              )}
            </button>
          </div>

          {!juryQuestion && !isLoadingQuestion && (
            <div className="p-8 text-center text-white/40 font-mono space-y-2 border border-dashed border-white/10">
              <p className="tracking-wider text-xs font-semibold">NO TRIAL COMPOSITION LOADED.</p>
              <p className="text-[10px] text-white/30 leading-relaxed uppercase">Click &apos;INIT_defense_QUESTION&apos; to trigger a custom AI jury query calibrated for {activePlot.width}m x {activePlot.length}m plot setbacks.</p>
            </div>
          )}

          {juryQuestion && (
            <div className="space-y-4">
              <div className="bg-white/5 tech-border p-4 font-mono space-y-2 rounded-none">
                <span className="text-[9px] text-white font-bold uppercase tracking-wider block">JURY CRITIQUE PROPOSAL</span>
                <p className="text-white/90 text-xs leading-relaxed italic">{juryQuestion}</p>
                <div className="pt-2 text-[9px] text-white/40 flex items-center space-x-2">
                  <span>AUDIT NODE:</span>
                  <span className="bg-white/10 border border-white/15 text-white/80 px-1.5 py-0.5 uppercase tracking-wide">{juryFocus}</span>
                </div>
              </div>

              {!juryFeedback && (
                <form onSubmit={handleSubmitDefense} className="space-y-3" id="jury-defense-form">
                  <div>
                    <span className="block text-[10px] font-mono text-white/40 uppercase mb-2">Student Defense Argument</span>
                    <textarea
                      id="student-defense-input"
                      value={userDefense}
                      onChange={(e) => setUserDefense(e.target.value)}
                      placeholder="Type your structural, geometric, and mathematical defense here..."
                      className="w-full h-24 bg-black/60 tech-border p-3 font-mono text-xs text-white outline-none focus:border-white transition-all rounded-none resize-none placeholder-white/20"
                      required
                    />
                  </div>

                  <button
                    id="submit-defense-btn"
                    type="submit"
                    disabled={isLoadingFeedback || !userDefense.trim()}
                    className="w-full py-2.5 bg-white border border-white text-black hover:bg-white/90 font-mono text-xs font-bold uppercase tracking-widest transition-all rounded-none flex items-center justify-center cursor-pointer disabled:opacity-50"
                  >
                    {isLoadingFeedback ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> APPRAISING RESPONSE
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5 mr-1.5" /> TRANSMIT_DEFENSE
                      </>
                    )}
                  </button>
                </form>
              )}

              {juryFeedback && (
                <div className="space-y-4">
                  <div className="bg-white/5 tech-border p-4 font-mono text-xs text-white/80 leading-normal space-y-3">
                    <span className="text-[9px] text-white font-bold uppercase tracking-widest block border-b border-white/10 pb-1">FORMAL EVALUATION LOG</span>
                    <div className="prose prose-invert prose-xs max-w-none text-white/80 space-y-2">
                      {juryFeedback.split('\n').map((line, i) => (
                        <p key={i} className="m-0">{line}</p>
                      ))}
                    </div>
                  </div>

                  <button
                    id="reset-jury-btn"
                    onClick={() => {
                      setJuryQuestion('');
                      setJuryFeedback('');
                      setUserDefense('');
                    }}
                    className="w-full py-2.5 bg-transparent tech-border border-white/10 hover:border-white text-white/60 hover:text-white font-mono text-xs uppercase tracking-wider rounded-none transition-all cursor-pointer"
                  >
                    RESET DEFENSE ENGINE & TRY ANOTHER INSTITUTE
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
