import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Sparkles, RefreshCw } from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  parts: { text: string }[];
  timestamp: Date;
}

interface Props {
  activePlot: any;
  activeReport: any;
}

export default function StudioConsole({ activePlot, activeReport }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      parts: [{ text: "Welcome to Yaan.Ai Spatial Intelligence Core. System status is nominal. Ready for spatial analysis directives." }],
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isSending) return;

    const userText = inputText;
    setInputText('');
    setIsSending(true);

    const userMsg: ChatMessage = {
      id: `m-user-${Date.now()}`,
      role: 'user',
      parts: [{ text: userText }],
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userText,
          history: messages.map(m => ({ role: m.role, parts: m.parts })),
          spatialContext: { activePlot, activeReport }
        })
      });

      if (!response.ok) throw new Error('API communication failed');
      const data = await response.json();

      const modelMsg: ChatMessage = {
        id: `m-model-${Date.now()}`,
        role: 'model',
        parts: [{ text: data.text || "No response received." }],
        timestamp: new Date()
      };
      setMessages(prev => [...prev, modelMsg]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, {
        id: `m-err-${Date.now()}`,
        role: 'model',
        parts: [{ text: "Error: Unable to reach Spatial Core Server. Please check your connection." }],
        timestamp: new Date()
      }]);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-white relative z-10" id="compliance-workspace">
      {/* Parameters Panel */}
      <div className="lg:col-span-5 bg-black/40 backdrop-blur-md tech-border p-6 flex flex-col justify-between" id="parameters-panel">
        <div>
          {/* Brand Logo Header - Standard Wrap to prevent overflow */}
          <div className="flex items-start space-x-3 border-b border-white/10 pb-4 mb-6 min-w-0">
            <div className="text-2xl font-extrabold tracking-tight text-white font-sans select-none shrink-0">
              Yaan<span className="text-white/60">.Ai</span>
            </div>
            <div className="border-l border-white/20 pl-3 min-w-0 flex-1">
              <h1 className="text-[10px] font-bold tracking-wider text-white uppercase leading-tight break-words">
                SPATIAL GENERATIVE STUDIO
              </h1>
              <p className="text-[8px] text-white/40 font-mono tracking-tighter uppercase mt-1 leading-normal break-words">
                ARCHITECTURAL INTELLIGENCE CORE // SURAJ SMC-AUDA DIRECTIVE
              </p>
            </div>
          </div>

          {/* Spatial Metadata Section */}
          <div className="space-y-4 font-mono text-xs">
            <div className="bg-white/5 border border-white/10 p-4 rounded space-y-2">
              <div className="flex justify-between border-b border-white/5 pb-1">
                <span className="text-white/40">CORE STATUS:</span>
                <span className="text-emerald-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> ONLINE
                </span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-1">
                <span className="text-white/40">ACTIVE PLOT:</span>
                <span>{activePlot ? `${activePlot.width}m x ${activePlot.length}m` : 'DEFAULT_GRID'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/40">ZONING COMPLIANCE:</span>
                <span className="text-indigo-400">GDCR_2026_v2</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-white/5 text-[10px] text-white/30 font-mono flex justify-between items-center">
          <span>SECURE ENCRYPTED SYSTEM</span>
          <span>SYS_REV_4.8.2</span>
        </div>
      </div>

      {/* Interactive AI Chat Console */}
      <div className="lg:col-span-7 bg-black/40 backdrop-blur-md tech-border p-6 flex flex-col h-[600px]" id="console-panel">
        <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <Bot className="w-4 h-4 text-white/60" />
            <span className="font-mono text-xs tracking-wider uppercase text-white/80">CORE AI TERMINAL</span>
          </div>
          <span className="text-[10px] font-mono bg-white/10 px-2 py-0.5 rounded text-white/60">GEN-AI // ACTIVE</span>
        </div>

        {/* Chat Messages Stream */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2 font-sans text-sm scrollbar-thin">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              {msg.role !== 'user' && (
                <div className="w-7 h-7 rounded bg-white/10 border border-white/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Sparkles className="w-4 h-4 text-white/80" />
                </div>
              )}
              <div className={`max-w-[85%] rounded p-3 text-xs leading-relaxed ${
                msg.role === 'user' 
                  ? 'bg-white text-black font-medium selection:bg-black selection:text-white' 
                  : 'bg-white/5 tech-border text-white/90 font-mono'
              }`}>
                {msg.parts[0].text}
              </div>
              {msg.role === 'user' && (
                <div className="w-7 h-7 rounded bg-white text-black flex items-center justify-center shrink-0 mt-0.5 font-bold text-xs">
                  U
                </div>
              )}
            </div>
          ))}
          {isSending && (
            <div className="flex gap-3 justify-start items-center">
              <div className="w-7 h-7 rounded bg-white/10 border border-white/10 flex items-center justify-center animate-spin">
                <RefreshCw className="w-3 h-3 text-white/60" />
              </div>
              <span className="text-[10px] font-mono text-white/40 animate-pulse">PROCESSING DATA QUERY...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Form Box */}
        <form onSubmit={handleSend} className="mt-4 flex gap-2 pt-3 border-t border-white/10">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Enter spatial query or code directive..."
            disabled={isSending}
            className="flex-1 bg-white/5 border border-white/10 rounded px-3 py-2 text-xs font-mono text-white placeholder-white/20 focus:outline-none focus:border-white/40 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={isSending || !inputText.trim()}
            className="bg-white hover:bg-white/90 disabled:bg-white/10 text-black disabled:text-white/20 px-4 rounded flex items-center justify-center transition-colors disabled:pointer-events-none"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
}