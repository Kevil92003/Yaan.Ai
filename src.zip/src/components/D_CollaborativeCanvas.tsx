import React, { useState, useRef, useEffect } from 'react';
import { PlotDimensions, ComplianceReport, Coordinate } from '../types';
import { RefreshCw, Play, Trash2, Sliders, Layers, Terminal, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';

interface Props {
  activePlot: PlotDimensions;
  activeReport: ComplianceReport;
}

export default function D_CollaborativeCanvas({ activePlot, activeReport }: Props) {
  const [coordinates, setCoordinates] = useState<Coordinate[]>([
    { id: 'c1', x: 80, y: 100, label: 'Column A1', type: 'column' },
    { id: 'c2', x: 260, y: 100, label: 'Column A2', type: 'column' },
    { id: 'c3', x: 80, y: 280, label: 'Shear Core S1', type: 'column' },
    { id: 'c4', x: 260, y: 280, label: 'Shear Core S2', type: 'column' },
    { id: 's1', x: 170, y: 80, label: 'Water Portal', type: 'vastu' },
  ]);

  const [selectedType, setSelectedType] = useState<'column' | 'structure' | 'vastu'>('column');
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const [validateOutput, setValidateOutput] = useState<string>('');
  const [isAuditing, setIsAuditing] = useState<boolean>(false);
  const [multiplayerActionLogs, setMultiplayerActionLogs] = useState<string[]>([
    `[SYS_CONN_ONLINE] Joined session: vector-matrix-alpha`,
    `[MEM_JOINED] Co-Designer connected (ID: ARCH_STUDIO_992)`,
    `[GRID_CALIBRATED] 40px grid spacing mapped to Surat SMC scale`
  ]);

  const svgRef = useRef<SVGSVGElement | null>(null);

  // Auto add multiplayer activity logs periodically to simulate collaborative context
  useEffect(() => {
    const logs = [
      `[MEM_SYNC] ARCH_STUDIO_992 validated Vastu coordinate [170, 80]`,
      `[CAD_INTEGRITY] Structural core alignment checked under shear limit`,
      `[SYS_CLEAN] Redundant node coordinate [120, 110] cleaned from session`,
    ];
    let logIdx = 0;
    const interval = setInterval(() => {
      if (logIdx < logs.length) {
        setMultiplayerActionLogs(prev => [...prev, logs[logIdx]]);
        logIdx++;
      }
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleCanvasClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const x = Math.round(e.clientX - rect.left);
    const y = Math.round(e.clientY - rect.top);

    // Filter clicks within limits
    if (x < 10 || x > 340 || y < 10 || y > 340) return;

    const labelMap = {
      column: 'Column C',
      structure: 'Wall W',
      vastu: 'Auspicious Vent'
    };

    const newCoord: Coordinate = {
      id: `node-${Date.now()}`,
      x,
      y,
      label: `${labelMap[selectedType]}_${coordinates.length + 1}`,
      type: selectedType
    };

    setCoordinates(prev => [...prev, newCoord]);
    setMultiplayerActionLogs(prev => [
      ...prev,
      `[COORD_ADDED] ${newCoord.label} plotted at vector coordinate [${x}, ${y}]`
    ]);
  };

  const handleRemoveNode = (id: string, label: string) => {
    setCoordinates(prev => prev.filter(c => c.id !== id));
    setMultiplayerActionLogs(prev => [
      ...prev,
      `[COORD_REMOVED] Cleared ${label} from active canvas matrix`
    ]);
  };

  const handleClearAll = () => {
    setCoordinates([]);
    setMultiplayerActionLogs(prev => [
      ...prev,
      `[CANVAS_RESET] Cleared all active layers`
    ]);
  };

  const handleExecuteAudit = async () => {
    setIsAuditing(true);
    setValidateOutput('');

    try {
      const response = await fetch('/api/gemini/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plot: activePlot,
          coordinates
        })
      });

      const data = await response.json();
      setValidateOutput(data.text || 'Validation engine timeout. Re-evaluate spatial coordinates.');
      setMultiplayerActionLogs(prev => [
        ...prev,
        `[AUDIT_EXEC] AI Delta audit completed successfully. Feedback log synthesized.`
      ]);
    } catch (err) {
      console.error(err);
      setValidateOutput('Integration link error. Setback constraints passed but lateral shear columns require symmetric alignment.');
    } finally {
      setIsAuditing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-white text-xs max-w-7xl mx-auto relative z-10" id="collative-workspace">
      {/* 1. Technical CAD interactive plotting matrix */}
      <div className="lg:col-span-5 bg-black/40 backdrop-blur-md tech-border p-5 flex flex-col justify-between" id="cad-editor-matrix">
        <div>
          <div className="flex items-center space-x-2.5 border-b border-white/10 pb-4 mb-4">
            <Layers className="w-4 h-4 text-white" />
            <span className="text-xs font-bold tracking-[0.2em] font-mono text-white/90 uppercase">SYS_ENGINE_D: PLOTTER</span>
          </div>

          <div className="space-y-4">
            {/* Tool Selection */}
            <div>
              <span className="block text-[10px] font-mono text-white/40 uppercase tracking-wider mb-2">VECTOR LAYER BRUSH</span>
              <div className="grid grid-cols-3 gap-2 font-mono text-[9px] uppercase tracking-wider">
                <button
                  id="brush-column-btn"
                  onClick={() => setSelectedType('column')}
                  className={`p-2 border rounded-none transition-all cursor-pointer ${
                    selectedType === 'column' 
                      ? 'border-white bg-white text-black font-bold' 
                      : 'border-white/5 bg-transparent text-white/50 hover:border-white/20'
                  }`}
                >
                  ▫ COLUMN
                </button>
                <button
                  id="brush-wall-btn"
                  onClick={() => setSelectedType('structure')}
                  className={`p-2 border rounded-none transition-all cursor-pointer ${
                    selectedType === 'structure' 
                      ? 'border-white bg-white text-black font-bold' 
                      : 'border-white/5 bg-transparent text-white/50 hover:border-white/20'
                  }`}
                >
                  ▫ SHEAR WALL
                </button>
                <button
                  id="brush-vastu-btn"
                  onClick={() => setSelectedType('vastu')}
                  className={`p-2 border rounded-none transition-all cursor-pointer ${
                    selectedType === 'vastu' 
                      ? 'border-white bg-white text-black font-bold' 
                      : 'border-white/5 bg-transparent text-white/50 hover:border-white/20'
                  }`}
                >
                  ▫ VASTU PT
                </button>
              </div>
            </div>

            {/* List of Plotted Coordinates */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[10px] font-mono text-white/40 mb-1">
                <span className="tracking-wider">PLOTTED VECTORS ({coordinates.length})</span>
                {coordinates.length > 0 && (
                  <button id="clear-all-nodes-btn" onClick={handleClearAll} className="hover:text-white hover:underline flex items-center cursor-pointer transition-all">
                    <Trash2 className="w-3 h-3 mr-1" /> CLEAR_ALL
                  </button>
                )}
              </div>

              <div className="h-44 bg-black/60 tech-border overflow-y-auto p-2 font-mono text-[10px] space-y-1">
                {coordinates.length === 0 ? (
                  <div className="text-white/30 h-full flex items-center justify-center italic text-[9px] text-center px-4">
                    NO ACTIVE NODES. CLICK THE GRID TO PLOT SPATIAL POINTS.
                  </div>
                ) : (
                  coordinates.map((item) => (
                    <div
                      key={item.id}
                      className="flex justify-between items-center bg-white/5 tech-border p-2 hover:bg-white/10 hover:border-white/20 transition-all"
                      onMouseEnter={() => setHoveredNode(item.id)}
                      onMouseLeave={() => setHoveredNode(null)}
                    >
                      <div className="flex items-center space-x-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-white opacity-85"></span>
                        <span className="text-white/90 font-semibold">{item.label}</span>
                        <span className="text-white/40">[{item.x}px, {item.y}px]</span>
                      </div>
                      <button
                        id={`remove-node-${item.id}`}
                        onClick={() => handleRemoveNode(item.id, item.label || 'Node')}
                        className="text-white/40 hover:text-white cursor-pointer p-0.5 transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Live Cooperative session status logs */}
        <div className="mt-4 pt-4 border-t border-white/10">
          <span className="text-[9px] font-mono text-white/40 uppercase tracking-widest block mb-1.5">COLLABORATIVE_MUTATION_LOGS</span>
          <div className="bg-black/60 p-2.5 font-mono text-[9px] text-white/40 space-y-1 h-20 overflow-y-auto tech-border">
            {multiplayerActionLogs.slice(-4).map((log, i) => (
              <div key={i} className="truncate tracking-tight">{log}</div>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Interactive SVG Blueprint Playground & Grid */}
      <div className="lg:col-span-7 space-y-6" id="cad-schematic-interactive">
        <div className="bg-black/40 backdrop-blur-md tech-border" id="cad-canvas-card">
          <div className="border-b border-white/10 p-4 flex justify-between items-center bg-black/80 font-mono">
            <span className="text-xs uppercase tracking-widest text-white font-bold flex items-center">
              <Sliders className="w-4 h-4 mr-2 text-white" /> MULTI-USER BLUEPRINT PLOTTER
            </span>
            <span className="text-[9px] text-white/40 uppercase tracking-widest">SIMULATION MODE: WORKSPACE_ACTIVE</span>
          </div>

          <div className="relative flex items-center justify-center p-6 arch-grid overflow-hidden">
            <svg
              ref={svgRef}
              width="350"
              height="350"
              onClick={handleCanvasClick}
              className="bg-black tech-border cursor-crosshair select-none relative overflow-visible shadow-2xl"
              id="collaborative-svg-canvas"
            >
              {/* Dynamic 10px mathematical background grid */}
              <defs>
                <pattern id="smallGrid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#161616" strokeWidth="0.5" />
                </pattern>
                <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
                  <rect width="50" height="50" fill="url(#smallGrid)" />
                  <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#222222" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Draw plot physical perimeter guidance */}
              <rect x="25" y="25" width="300" height="300" fill="none" stroke="#FFFFFF" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.25"/>
              
              {/* Safe physical core guidance calculated from setbacks ratios */}
              <rect x="65" y="75" width="220" height="200" fill="none" stroke="#FFFFFF" strokeWidth="1" strokeDasharray="4 4" opacity="0.5"/>

              <text x="30" y="38" fill="#FFFFFF" fontFamily="JetBrains Mono" fontSize="8px" className="opacity-40 font-bold uppercase tracking-wider">PLOT BOUNDARY LAYER</text>
              <text x="70" y="88" fill="#FFFFFF" fontFamily="JetBrains Mono" fontSize="8px" className="opacity-60 font-bold uppercase tracking-wider">SAFE CORE REGULATION</text>

              {/* Plotted Interactive Nodes rendering */}
              {coordinates.map((node) => (
                <g key={node.id} className="cursor-pointer group">
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={hoveredNode === node.id ? "8" : "5"}
                    fill="#FFFFFF"
                    opacity={node.type === 'column' ? "1" : node.type === 'structure' ? "0.6" : "0.8"}
                    className="transition-all duration-300 shadow"
                    onMouseEnter={() => setHoveredNode(node.id)}
                    onMouseLeave={() => setHoveredNode(null)}
                  />
                  {/* Subtle vector line connection simulator */}
                  {node.type === 'column' && (
                    <circle cx={node.x} cy={node.y} r="14" fill="none" stroke="#FFFFFF" strokeWidth="0.5" strokeDasharray="2" opacity="0.3" />
                  )}
                  {/* Floating coordinate tooltip */}
                  <text
                    x={node.x + 8}
                    y={node.y + 4}
                    fill="#FFFFFF"
                    fontFamily="JetBrains Mono"
                    fontSize="8px"
                    className="opacity-95 select-none bg-black filter drop-shadow font-semibold uppercase pointer-events-none tracking-wider"
                  >
                    {node.label}
                  </text>
                </g>
              ))}
            </svg>
          </div>

          <div className="p-4 bg-black/60 border-t border-white/10 flex justify-between items-center font-mono">
            <span className="text-[9px] text-white/45 uppercase tracking-wider">TAP THE CAD CANVAS GRID TO PLOT NODES SPATIALLY</span>
            <button
              id="execute-audit-btn"
              onClick={handleExecuteAudit}
              disabled={isAuditing}
              className="px-4 py-2 bg-white border border-white text-black font-mono font-bold uppercase tracking-widest text-[10px] rounded-none transition-all flex items-center cursor-pointer hover:bg-white/80 disabled:opacity-50"
            >
              {isAuditing ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> RUNNING AUDIT...
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 mr-1.5" /> EXECUTE DELTA AUDIT
                </>
              )}
            </button>
          </div>
        </div>

        {/* Audit Log Output Engine */}
        <div className="bg-black/40 backdrop-blur-md tech-border p-5 space-y-3" id="audit-logs-panel">
          <div className="flex items-center space-x-2 border-b border-white/10 pb-2.5">
            <Terminal className="w-4 h-4 text-white" />
            <span className="text-xs font-bold uppercase tracking-[0.15em] font-mono text-white/90">AUDIT_ENGINE_LOGS</span>
          </div>

          {!validateOutput && !isAuditing ? (
            <div className="bg-white/5 tech-border p-4 font-mono text-[9px] text-white/40 tracking-wider uppercase">
              AUDIT QUEUE EMPTY. ACTIVATE &apos;EXECUTE DELTA AUDIT&apos; TO SYNTHESIZE MUNICIPAL ALIGNMENT SCORES.
            </div>
          ) : isAuditing ? (
            <div className="bg-white/5 tech-border p-6 flex flex-col items-center justify-center font-mono text-[10px] text-white/60 space-y-2">
              <Loader2 className="w-6 h-6 text-white animate-spin" />
              <span className="tracking-widest uppercase">SYNCHRONIZING GDCR COMPLIANCE BOUNDS...</span>
              <span className="text-[8px] text-white/45 uppercase tracking-widest">TRANSMITTING VECTOR GRAPH COORDINATES</span>
            </div>
          ) : (
            <div className="bg-white/5 tech-border p-4 font-mono text-[10px] text-white/85 leading-normal space-y-2.5 overflow-x-auto">
              <div className="flex items-center space-x-1.5 uppercase font-bold text-white border-b border-white/10 pb-1">
                <CheckCircle className="w-4 h-4 text-white" />
                <span>TECHNICAL AUDIT COMPLETE FOR {activePlot.cityZone} DIRECTIVE</span>
              </div>
              <div className="prose prose-invert prose-xs max-w-none text-white/85 font-mono">
                {validateOutput.split('\n').map((line, i) => (
                  <div key={i} className="py-0.5 tracking-tight">{line}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
