export interface Coordinate {
  id: string;
  x: number;
  y: number;
  label?: string;
  type?: 'boundary' | 'setback' | 'structure' | 'column' | 'vastu';
}

export interface PlotDimensions {
  width: number; // meters
  length: number; // meters
  cityZone: 'SURAT' | 'AHMEDABAD' | 'GIFT_CITY' | 'RAJKOT' | 'VADODARA';
  roadFacing: 'NORTH' | 'SOUTH' | 'EAST' | 'WEST';
  roadWidth: number; // meters
}

export interface SetbackGuidelines {
  front: number;
  rear: number;
  sideLeft: number;
  sideRight: number;
  maxHeight: number;
  maxFSI: number;
}

export interface ComplianceDelta {
  parameter: string;
  required: string | number;
  actual: string | number;
  status: 'PASS' | 'FAIL' | 'CONDITIONAL';
  remediation?: string;
}

export interface ComplianceReport {
  city: string;
  applicableCode: string;
  boundsCompliant: boolean;
  setbacks: SetbackGuidelines;
  deltas: ComplianceDelta[];
  vastuAssessment: {
    agniValid: boolean;
    vayuValid: boolean;
    ishanyaValid: boolean;
    nairutyaValid: boolean;
    suggestions: string[];
  };
}

export interface UniversityNode {
  id: string;
  name: string;
  location: string;
  focus: string;
  keyDeliverable: string;
  syllabi: {
    semester: string;
    courseName: string;
    submissionCriteria: string[];
    gradingFocus: string[];
  }[];
  defenseQuestions: {
    question: string;
    focusArea: string;
    hint: string;
  }[];
}

export interface RealEstateEnterprise {
  id: string;
  name: string;
  founder: string;
  specialty: string;
  signatureStyle: string;
  bimDetail: string;
  loadThermalParams: string;
  marketAlignment: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}
