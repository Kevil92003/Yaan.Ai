import { useState } from 'react';
import { PlotDimensions, ComplianceReport } from './types';
import A_SpatialCompliance from './components/A_SpatialCompliance';
import B_AcademicKnowledge from './components/B_AcademicKnowledge';
import C_CorporateDirectory from './components/C_CorporateDirectory';
import D_CollaborativeCanvas from './components/D_CollaborativeCanvas';
import StudioConsole from './components/StudioConsole';
import { LayoutGrid, GraduationCap, Building2, Layers, Command, Code } from 'lucide-react';

export default function App() {
  const [activeEngine, setActiveEngine] = useState<'A' | 'B' | 'C' | 'D'>('A');

  // Unified global coordinate/plot state synchronized across compliant engines
  const [plot, setPlot] = useState<PlotDimensions>({
    width: 30,
    length: 40,
    cityZone: 'SURAT',
    roadFacing: 'NORTH',
    roadWidth: 18,
  });

  const [report, setReport] = useState<ComplianceReport>({
    city: 'SURAT',
    applicableCode: 'SMC Unified Grid Framework - GDCR 2025',
    boundsCompliant: true,
    setbacks: {
      front: 4.5,
      rear: 3.0,
      sideLeft: 2.5,
      sideRight: 2.5,
      maxHeight: 24,
      maxFSI: 2.7,
    },
    deltas: [],
    vastuAssessment: {
      agniValid: true,
      vayuValid: true,
      ishanyaValid: true,
      nairutyaValid: true,
      suggestions: ['Auspicious layout alignment complete'],
    },
  });

  const handleReportSync = (newReport: ComplianceReport, newPlot: PlotDimensions) => {
    setReport(newReport);
    setPlot(newPlot);
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col font-sans select-none relative overflow-x-hidden" id="yaan-studio-container">
      {/* Immersive Atmospheric Grid Background Overlay */}
      <div className="absolute inset-0 grid-bg opacity-20 pointer-events-none z-0"></div>

      {/* 1. Header Frame - Pure Precision Architecture */}
      <header className="tech-border border-t-0 border-x-0 bg-black/80 backdrop-blur-md px-6 py-4 flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0 z-10" id="studio-header">
        <div className="flex items-center space-x-3.5">
          <div className="p-2 tech-border bg-white/5 flex items-center justify-center">
            <Command className="w-5 h-5 text-white/95 rotate-45" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold tracking-[0.3em] text-white uppercase">YAAN.AI | SPATIAL GENERATIVE STUDIO</span>
              <span className="text-[8px] bg-white/10 tech-border text-white/60 font-mono px-1 py-0.5 uppercase tracking-widest leading-none">v4.0.2</span>
            </div>
            <p className="text-[9px] opacity-40 uppercase tracking-widest font-mono mt-0.5">
              Architectural Intelligence Core // Suraj SMC-AUDA Directive
            </p>
          </div>
        </div>

        {/* Studio Leadership & Operational Signature */}
        <div className="text-left md:text-right font-mono" id="operational-control-tag">
          <span className="text-[9px] opacity-40 uppercase tracking-widest block">Operational Control</span>
          <span className="text-xs font-bold tracking-widest text-white uppercase block mt-0.5">
            FOUNDER: MR. KEVIL SOLANKI
          </span>
        </div>
      </header>

      {/* 2. Primary Feature Navigation Controls */}
      <nav className="tech-border border-t-0 border-x-0 bg-black/60 backdrop-blur-md px-6 py-2.5 overflow-x-auto shrink-0 z-10" id="feature-engine-nav">
        <div className="flex space-x-3 min-w-max font-mono text-[10px] uppercase tracking-wider">
          <button
            id="engine-a-nav-btn"
            onClick={() => setActiveEngine('A')}
            className={`px-3 py-1.5 flex items-center space-x-2 tech-border transition-all rounded-none cursor-pointer ${
              activeEngine === 'A'
                ? 'bg-white text-black font-bold'
                : 'bg-white/5 border-white/5 text-white/40 hover:text-white/80 hover:bg-white/10 opacity-60 hover:opacity-100'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>ENGINE A: GDCR COMPLIANCE</span>
            {activeEngine === 'A' && <span className="text-[8px] ml-1 bg-black text-white px-1 font-bold">LIVE</span>}
          </button>

          <button
            id="engine-b-nav-btn"
            onClick={() => setActiveEngine('B')}
            className={`px-3 py-1.5 flex items-center space-x-2 tech-border transition-all rounded-none cursor-pointer ${
              activeEngine === 'B'
                ? 'bg-white text-black font-bold'
                : 'bg-white/5 border-white/5 text-white/40 hover:text-white/80 hover:bg-white/10 opacity-60 hover:opacity-100'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>ENGINE B: ACADEMIC UNIVERSITY HUB</span>
            {activeEngine === 'B' && <span className="text-[8px] ml-1 bg-black text-white px-1 font-bold">LIVE</span>}
          </button>

          <button
            id="engine-c-nav-btn"
            onClick={() => setActiveEngine('C')}
            className={`px-3 py-1.5 flex items-center space-x-2 tech-border transition-all rounded-none cursor-pointer ${
              activeEngine === 'C'
                ? 'bg-white text-black font-bold'
                : 'bg-white/5 border-white/5 text-white/40 hover:text-white/80 hover:bg-white/10 opacity-60 hover:opacity-100'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>ENGINE C: REAL ESTATE DIRECTORY</span>
            {activeEngine === 'C' && <span className="text-[8px] ml-1 bg-black text-white px-1 font-bold">LIVE</span>}
          </button>

          <button
            id="engine-d-nav-btn"
            onClick={() => setActiveEngine('D')}
            className={`px-3 py-1.5 flex items-center space-x-2 tech-border transition-all rounded-none cursor-pointer ${
              activeEngine === 'D'
                ? 'bg-white text-black font-bold'
                : 'bg-white/5 border-white/5 text-white/40 hover:text-white/80 hover:bg-white/10 opacity-60 hover:opacity-100'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>ENGINE D: BLUEPRINT COORDINATES PLOTTER</span>
            {activeEngine === 'D' && <span className="text-[8px] ml-1 bg-black text-white px-1 font-bold">LIVE</span>}
          </button>
        </div>
      </nav>

      {/* 3. Main Workspace Split Layout */}
      <main className="flex-1 p-6 space-y-8 z-10" id="primary-workspace">
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
          
          {/* Active Feature Core Section */}
          <section className="xl:col-span-8 space-y-6" id="feature-engine-container">
            {activeEngine === 'A' && (
              <div id="feature-a-workspace" className="space-y-4">
                <div className="border-l border-white/30 pl-4 py-1">
                  <h1 className="text-xs font-bold tracking-[0.2em] font-mono text-white/90 uppercase">SPATIAL DIAGNOSTIC &amp; GDCR COMPLIANCE MATRIX</h1>
                  <p className="text-[10px] opacity-40 font-mono mt-0.5 uppercase tracking-wider">Gujarat urban zoning codes validation. SMC Unified Grid alignment, AUDA corridor setbacks, and thermodynamic Vastu matrix checks.</p>
                </div>
                <A_SpatialCompliance onReportChange={handleReportSync} />
              </div>
            )}

            {activeEngine === 'B' && (
              <div id="feature-b-workspace" className="space-y-4">
                <div className="border-l border-white/30 pl-4 py-1">
                  <h1 className="text-xs font-bold tracking-[0.2em] font-mono text-white/90 uppercase">GUJARAT ACADEMIC UNIVERSITY KNOWLEDGE REPOSITORY</h1>
                  <p className="text-[10px] opacity-40 font-mono mt-0.5 uppercase tracking-wider">Curriculum architectures, submission directives, and dynamic trial thesis defense simulators for CEPT, Nirma, MSU and SCET.</p>
                </div>
                <B_AcademicKnowledge activePlot={plot} activeReport={report} />
              </div>
            )}

            {activeEngine === 'C' && (
              <div id="feature-c-workspace" className="space-y-4">
                <div className="border-l border-white/30 pl-4 py-1">
                  <h1 className="text-xs font-bold tracking-[0.2em] font-mono text-white/90 uppercase">GUJARAT REAL ESTATE CORPORATE BLUEPRINT DIRECTORY</h1>
                  <p className="text-[10px] opacity-40 font-mono mt-0.5 uppercase tracking-wider">Developer profiles, signature BIM standards, structural engineering styles, thermal parameters modeling, and compatibility alignment.</p>
                </div>
                <C_CorporateDirectory activePlot={plot} activeReport={report} />
              </div>
            )}

            {activeEngine === 'D' && (
              <div id="feature-d-workspace" className="space-y-4">
                <div className="border-l border-white/30 pl-4 py-1">
                  <h1 className="text-xs font-bold tracking-[0.2em] font-mono text-white/90 uppercase">COOPERATIVE BLUEPRINT PLOTTER &amp; INTEGRATED CANVAS</h1>
                  <p className="text-[10px] opacity-40 font-mono mt-0.5 uppercase tracking-wider">Plot structural layers (Columns, Shear cores) on vector coordinate lattices and execute AI Delta Audits under cooperative environments.</p>
                </div>
                <D_CollaborativeCanvas activePlot={plot} activeReport={report} />
              </div>
            )}
          </section>

          {/* V. AI Assistant Console (Unified Sidepanel Widget) */}
          <section className="xl:col-span-4 space-y-4" id="console-sidebar">
            <div className="p-2 bg-black/70 backdrop-blur-sm tech-border font-mono text-[9px] text-white/60 uppercase flex items-center justify-between">
              <span className="tracking-widest">ACTIVE EXECUTIVE LINK: MR. KEVIL SOLANKI</span>
              <span className="flex items-center text-white font-bold">
                <span className="w-1.5 h-1.5 bg-white mr-1.5 animate-pulse"></span>
                MATRIX ONLINE
              </span>
            </div>
            
            <StudioConsole activePlot={plot} activeReport={report} />

            <div className="bg-black/40 backdrop-blur-sm tech-border p-5 space-y-3 rounded-none" id="studio-dashboard-status">
              <span className="stat-label block border-b border-white/10 pb-2">
                COORDINATE MATRIX LOG
              </span>
              <div className="grid grid-cols-2 gap-3 text-[11px] font-mono">
                <div className="text-white/45 uppercase tracking-wider">PLOT AREA: <span className="text-white font-bold block mt-0.5">{(plot.width * plot.length).toFixed(1)} m²</span></div>
                <div className="text-white/45 uppercase tracking-wider">ROAD AXIS: <span className="text-white font-bold block mt-0.5">{plot.roadFacing}</span></div>
                <div className="text-white/45 uppercase tracking-wider">FSI DEPTH: <span className="text-white font-bold block mt-0.5">{report.setbacks.maxFSI.toFixed(2)} Index</span></div>
                <div className="text-white/45 uppercase tracking-wider">MAX HEIGHT: <span className="text-white font-bold block mt-0.5">{report.setbacks.maxHeight}m</span></div>
              </div>
            </div>
          </section>
        </div>
      </main>

      {/* 4. Architectural Fine-Line Footer info strip */}
      <footer className="tech-border border-b-0 border-x-0 px-6 py-3.5 flex justify-between items-center text-[10px] font-mono bg-black z-10" id="studio-footer">
        <div className="flex gap-6 items-center">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 bg-white"></div>
            <span className="uppercase tracking-widest font-medium">YAAN.AI Spatial Core &copy; 2026</span>
          </div>
          <div className="w-px h-3 bg-white/20"></div>
          <span className="opacity-45 uppercase tracking-widest hidden sm:inline">Certified under SMC-AUDA Codes</span>
        </div>
        <span className="tracking-widest opacity-60 uppercase">GUJARAT URBAN FRAMEWORK ALIGNMENT [VER 24.9]</span>
      </footer>
    </div>
  );
}
